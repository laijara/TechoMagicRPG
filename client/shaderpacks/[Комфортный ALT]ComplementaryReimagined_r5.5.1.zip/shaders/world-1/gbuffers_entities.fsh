#version 150

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform int entityId;

in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord2;

out vec4 fragColor;

void main() {
    vec4 color = texture(gtexture, texCoord0) * vertexColor;
    vec4 light = texture(lightmap, texCoord2);

    if (color.a < 0.1) {
        discard;
    }

    if (entityId == 10001) {
        float gray = dot(color.rgb, vec3(0.299, 0.587, 0.114));
        vec3 grayscale = vec3(gray) * light.rgb;
        vec3 brightened = mix(grayscale, vec3(1.0), 0.8);
        fragColor = vec4(brightened, color.a);
    } else {
        fragColor = color * light;
    }
}